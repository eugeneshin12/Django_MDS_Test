from django.apps import AppConfig


class MdsConfig(AppConfig):
    name = 'mds'
