from django.contrib import admin
from .models import Project, MR

admin.site.register(Project)
admin.site.register(MR)



# Register your models here.
