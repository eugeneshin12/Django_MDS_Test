from django.apps import AppConfig


class Mds02Config(AppConfig):
    name = 'mds02'
